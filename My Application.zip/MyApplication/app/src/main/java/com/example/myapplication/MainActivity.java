package com.example.myapplication;


import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import  android.hardware.*;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.Manifest;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.security.Policy;
import java.util.List;

class MyClickListener implements View.OnClickListener{

    @Override
    public void onClick(View view) {
        Log.i("MyClickListener", "onClick:call method ");
       // Toast.makeText(this,R.string.app_name,Toast.LENGTH_LONG).show();
    }
}


public class MainActivity extends AppCompatActivity {// implements View.OnClickListener {

    Camera camera;
    Button button;
    boolean hasFlash;
    boolean isFlashOn;
    Camera.Parameters params;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Setting");


        Dexter
                .withActivity(this)
                .withPermissions(Manifest.permission.CAMERA)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {

                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {

                    }
                }).check();


        hasFlash = getApplicationContext()
                .getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);



        if (!hasFlash){
            getSupportActionBar().setTitle("No Flash");
        }else {
            getCamera();
        }
        Button btn = findViewById(R.id.btn_one);

        btn.setOnClickListener(view -> {
            Log.i("9999999999999", "onCreate: ");
//            if (!hasFlash){
//                //Toast.makeText(this, "Flash off", Toast.LENGTH_LONG).show();
//                getSupportActionBar().setTitle("Flash Off");
//            }else{
//                //Toast.makeText(this, "Flash onn", Toast.LENGTH_LONG).show();
//                getSupportActionBar().setTitle("Flash Onn");
//                getCamera();
//            }
            if (!isFlashOn){
                //Toast.makeText(this, "Flash off", Toast.LENGTH_LONG).show();
                getSupportActionBar().setTitle("Flash Onn");
                getSupportActionBar().setBackgroundDrawable(new ColorDrawable(0xFF00DDED));
                getOnn();
            }else {
                //Toast.makeText(this, "Flash onn", Toast.LENGTH_LONG).show();
                getSupportActionBar().setTitle("Flash Off");
                getSupportActionBar().setBackgroundDrawable(new ColorDrawable(0xFC34DDED));
                getOff();
            }
   });





       // btn.setOnClickListener(new MyClickListener());


//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Log.i("View.OnClickListener() ", "onClick:call method 2");
//           //     Toast.makeText(getApplicationContext(),R.string.app_name,Toast.LENGTH_LONG).show();
//                Toast.makeText(MainActivity.this,R.string.app_name,Toast.LENGTH_LONG).show();
//            }
//        });


//        btn.setOnClickListener(view -> {
//            Toast.makeText(MainActivity.this,R.string.app_name,Toast.LENGTH_LONG).show();
//        });


      // btn.setOnClickListener(this);
    }

    public void getCamera(){
        if (camera == null){
            try {
                camera = Camera.open();
                Toast.makeText(MainActivity.this,"Камеру удалось заполучить!",Toast.LENGTH_LONG).show();
            }catch (Exception exception){
                getSupportActionBar().setTitle("getCamera ERROR");
            }
        }
    }
    public void getOnn(){
//        if (!isFlashOn){
            if (camera == null || !hasFlash){
                return;
            }
            params = camera.getParameters();
            params.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
            camera.setParameters(params);
            camera.startPreview();
            isFlashOn = true;
        //}
    }
    public void getOff(){
        //if (isFlashOn){
            if (camera == null || !hasFlash){
                return;
            }
            params = camera.getParameters();
            params.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(params);
            camera.stopPreview();
            isFlashOn = false;
        //}
    }


//    public void onMyClick(View view) {
//        Toast.makeText(this,R.string.app_name,Toast.LENGTH_LONG).show();
//    }
//
//    @Override
//    public void onClick(View view) {
//        //Toast.LENGTH_LONG   3500 ms
//        //Toast.LENGTH_SHORT  2000 ms
////       Toast tst =  Toast.makeText(MainActivity.this,R.string.app_name,Toast.LENGTH_LONG);
//////        tst.setGravity(Gravity.CENTER,0,250);
////        tst.setGravity(Gravity.BOTTOM | Gravity.RIGHT,0,-250);
////       tst.show();
//
//    }
}